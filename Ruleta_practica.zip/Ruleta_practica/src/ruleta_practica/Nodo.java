package ruleta_practica;

public class Nodo {

    String nombre;
    int num;
    int apuesta;
    int saldo;
    int ID;
    int Pganadas;
    Nodo siguiente;
    
    //////////// PRUEBA DE ARRAY    
    //int eleccion;// Esta variable le dara el tamaño a la matriz
    //int matriz []=new int[eleccion];
    //
    /////////// PRUEBA DE ARRAY

}
