package ruleta_practica;

import java.io.IOException;
import java.util.Scanner;

public class Ruleta_practica {

    public static void main(String[] args) throws IOException {

        System.out.println("///////////////////////"); ///MENÚ DE PRUEBAS
        System.out.println("//     BIENVENIDO    //");
        System.out.println("///////////////////////");
        System.out.println("ACTUALIZADO HORA: 9 PM");
        System.out.println("");

        ////Variables
        String nombre = "";
        int apuesta = 0;
        int num = 0;

        int opc = 0;
        int opc1 = 0;
        int a = 0;
        int ID = 0;
        int saldo = 0;
        int Pganadas = 0;
        //int matriz[] = null;  //Recuerda que está nulo puedes darle el valor 0 si quieres

        Scanner entrada = new Scanner(System.in);

        ////////////////////Para comunicar la clase Personas con la principal (Por ahora)
        Personas mensajero = new Personas(a);
        //////////////////////

        ////////////////////Para comunicar la clase Cola con la principal (Por ahora)
        Cola cola = new Cola();
        ////////////////////

        //Nodo envio = new Nodo(nombre, apuesta);
        do {
            
             System.out.println("\033[31m**********************************");
            System.out.println("\033[30m**********************************");
            System.out.println("\033[30mBIENVENIDO AL \033[31m CASINO MOULIN ROUGE");
            System.out.println("\033[31m**********************************");
            System.out.println("\033[30m**********************************");
            
            
            System.out.println("\033[31m 1- JUGADORES");       //MENÚ DE PRUEBAS
            System.out.println("\033[31m 2- Ruleta (En proceso)");
            System.out.println("\033[31m 3- AYUDA");
            System.out.println("\033[31m 4- Salir");
            System.out.println("____________________________________");
            System.out.print("\033[32m Opción: ");
            opc = entrada.nextInt();
            System.out.println("____________________________________");

            switch (opc) {

                case 1:
                    do {
                        System.out.println("\033[31m 1- Ingresar Jugador");
                        System.out.println("\033[30m 2- ¿Está la lista vacía?");
                        System.out.println("\033[31m 3- Mostrar contenido de la lista");
                        System.out.println("\033[30m 4- Leer archivo");
                        System.out.println("\033[31m 5- Modificar datos");
                        System.out.println("\033[30m 6- SALIR al menú principal");
                        System.out.println("____________________________________");
                        System.out.print("\033[32m Opcion: ");
                        opc1 = entrada.nextInt();
                        System.out.println("____________________________________");

                        switch (opc1) {

                            case 1:
                                //  cola.insertar(nombre, apuesta, num, ID, saldo, Pganadas, eleccion, matriz[]);
                                cola.insertar(nombre, apuesta, num, ID, saldo, Pganadas);
                                break;

                            case 2:
                                cola.vacio();
                                break;

                            case 3:
                                cola.Mostrar();
                                break;

                            case 4:
                                cola.leer();
                                break;

                            case 5:
                                cola.Modificardatos();
                                break;

                            case 6:
                                opc1 = 10;
                                break;

                            default:
                                System.out.println("Opción incorrecta");

                        }

                    } while (opc1 < 6);
                    break;

                case 2:
                    do {
                        System.out.println("");
                        System.out.println("\033[31m 1- JUGAR RULETA");
                        System.out.println("\033[30m 2- Ver ganadores");
                        System.out.println("\033[31m 3- SALIR al menú principal");
                        System.out.println("____________________________________");
                        System.out.print("\033[32mOpcion: ");
                        opc1 = entrada.nextInt();
                        System.out.println("____________________________________");

                        switch (opc1) {
                            case 1:
                                cola.Ruleta();
                                break;

                            case 2:
                                cola.leerganadores();
                                break;

                            case 3:
                                opc1 = 10;
                                break;

                            default:
                                System.out.println("Opción incorrecta");

                        }
                    }while(opc1<4);
                    ////////////////////RULETA PRUEBA 2 (12:37PM)
                     System.out.println("");
                    break;

                case 3:
                    mensajero.Instrucciones();
                    break;

                case 4:
                    opc = 8;
                    break;

                default:
                    System.out.println("Opción incorrecta");
                    System.out.println("////////////////////////////");

            }

        } while (opc < 5);
    }

}
