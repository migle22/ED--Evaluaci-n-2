package ruleta_practica;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author OROZCO
 */
public class Cola {

    String Cola;
    Scanner entrada = new Scanner(System.in);
    int contador = 1;
    int partida=0;

    private Nodo iniciocola, finalcola;

    public Cola() {
        iniciocola = null;
        finalcola = null;
    }

    //Método para saber si está vacia
    public boolean colavacia() {
        if (iniciocola == null) {
            return true;
        } else {
            return false;

        }
    }

    // Método adicional para decir que está vacia
    public void vacio() {
        if (iniciocola == null) {
            System.out.println("No hay nadie todavía");

        } else {
            System.out.println("Hay jugadores");
        }

        System.out.println("____________________________________");
    }

    // Método para insertar
    public void insertar(String nombre, int apuesta, int num, int ID, int saldo, int Pganadas) {

        Nodo nuevo_nodo = new Nodo();

        System.out.print("Ingrese el nombre del jugador " + contador + ": ");
        nombre = entrada.next();
        System.out.print("Ingrese el saldo de su cuenta: ");
        saldo = entrada.nextInt();
        System.out.print("Ingrese su apuesta: ");
        apuesta = entrada.nextInt();

        //Pequeño ciclo para que el saldo no sea mayor a la apuesta
        if (apuesta > saldo) {
            while (apuesta > saldo) {
                System.out.println("");
                System.out.println("La apuesta no puede ser mayor al saldo, por favor ingrese los datos nuevamente");

                System.out.print("Ingrese el saldo de su cuenta: ");
                saldo = entrada.nextInt();
                System.out.print("Ingrese su apuesta: ");
                apuesta = entrada.nextInt();
                System.out.println("____________________________________");
            }

        }
        //Pequeño ciclo para que el saldo no sea mayor a la apuesta

        //Pequeño ciclo para que no escoja un número mayor o menor
        System.out.print("Número de la suerte: ");
        num = entrada.nextInt();
        if (num > 36) {
            while (num > 36) {
                System.out.println("");
                System.out.println("Por favor escoja un número entre 0 y 36");
                System.out.println("");
                System.out.print("Número de la suerte: ");
                num = entrada.nextInt();
            }

        } else {

        }

        //Pequeño ciclo para que no escoja un número mayor o menor
        System.out.println("____________________________________");

        ID = contador;

        nuevo_nodo.nombre = nombre;
        nuevo_nodo.apuesta = apuesta;
        nuevo_nodo.num = num;
        nuevo_nodo.ID = ID;
        nuevo_nodo.saldo = saldo;
        nuevo_nodo.Pganadas = Pganadas;

        try {

            FileWriter fw = new FileWriter("C:\\Users\\OROZCO\\Downloads\\Telegram Desktop\\JUGADOR" + contador + ".txt");

            fw.write(+contador + " Jugador\n\n");
            fw.write("Nombre: " + nombre + "\n Apuesta: " + apuesta + " $");
            fw.write("\n");
            fw.write("El número que escogió fue: " + num);
            fw.write("\n");
            fw.write("Posee un saldo de " + saldo + "$");
            fw.write("\n");
            fw.write("Partidas ganadas " + Pganadas);
            fw.write("\n");
            fw.write("Su número de identificación es: " + ID + "\n");
            fw.write("Los datos del jugador " + contador + " se guardaron exitosamente \n");

            fw.close();

        } catch (IOException ex) {
            Logger.getLogger(Personas.class.getName()).log(Level.SEVERE, null, ex);
        }
        nuevo_nodo.siguiente = null;

        contador++;

        if (colavacia()) {
            iniciocola = nuevo_nodo;
            finalcola = nuevo_nodo;
        } else {
            finalcola.siguiente = nuevo_nodo;
            finalcola = nuevo_nodo;
        }

        System.out.println("");

    }

    //Método para mostrar a los jugadores        
    public void Mostrar() {
        Nodo recorrer = iniciocola; //Recorrer es un Nodo auxiliar
        System.out.println("JUGADORES");
        System.out.println("");

        //Necesitamos recorrer todo desde el inicio
        while (recorrer != null) {

            System.out.println("Nombre:---[" + recorrer.nombre + "]---");
            System.out.println("Apuesta: [" + recorrer.apuesta + "]");
            System.out.println("Número: [" + recorrer.num + "]");
            System.out.println("Saldo: [" + recorrer.saldo + "]");
            System.out.println("Partidas ganadas: [" + recorrer.Pganadas + "]");
            System.out.println("ID: {" + recorrer.ID + "]");
            System.out.println("");
            recorrer = recorrer.siguiente;
        }
        System.out.println("____________________________________");
    }

    public void leer() throws IOException {

        int contadorlec = 1; //lec porque lo estamos usando para escoger si leeremos el 1, el 2, el 3, etc (Es una variable local)
        System.out.println("Por favor ingrese el número del jugador al que desea ingresar:");
        contadorlec = entrada.nextInt();

        try {
            FileReader fr = new FileReader("C:\\Users\\OROZCO\\Downloads\\Telegram Desktop\\JUGADOR" + contadorlec + ".txt");
            BufferedReader br = new BufferedReader(fr);
            String cadena;

            while ((cadena = br.readLine()) != null) {
                System.out.println("" + cadena);
            }

        } catch (Exception ex) {

        }

        System.out.println("____________________________________");

    }

    //PRUEBA DE LA RULETA DESDE LA CLASE COLA
    public void Ruleta() {
        int Ruleta = 0;
        
        String color;

        Ruleta = (int) (Math.random() * 37);

        if (Ruleta % 2 != 0) {
            color = "Negro";
        } else {
            color = "Rojo";
        }

        System.out.println("El número Ganador es el número " + Ruleta + " de Color " + color);

        Nodo recorrernum = iniciocola; //Recorrer es un Nodo auxiliar

        //Necesitamos recorrer todo desde el inicio
        while (recorrernum != null) {

            if (recorrernum.num == Ruleta) { //Ganador
                System.out.println("____________________________________");
                System.out.println("El ganador es:");
                System.out.println("Nombre: " + recorrernum.nombre);
                int aux = recorrernum.apuesta * 35;
                System.out.println("Apostó " + recorrernum.apuesta + " y ganó: " + aux);
                recorrernum.saldo = recorrernum.saldo + aux;
                System.out.println("Ahora tiene un saldo de: " + recorrernum.saldo);
                recorrernum.Pganadas++;
                System.out.println("____________________________________");

                try {

                    FileWriter fw = new FileWriter("C:\\Users\\OROZCO\\Downloads\\Telegram Desktop\\GANADORES"+contador+".txt");

                    fw.write(" GANADOR DE LA PARTIDA "+contador+" \n\n");
                    fw.write("Nombre: " + recorrernum.nombre + "\n Apuesta: " + recorrernum.apuesta + " $");
                    fw.write("\n");
                    fw.write("El número que escogió fue: " + recorrernum.num);
                    fw.write("\n");
                    fw.write("Ganó: " + aux);
                    fw.write("Posee un saldo de " + recorrernum.saldo + "$");
                    fw.write("\n");
                    fw.write("Partidas ganadas " + recorrernum.Pganadas);
                    fw.write("\n");
                    fw.write("Su número de identificación es: " + recorrernum.ID + "\n");
                    fw.write("Los datos del jugador " + recorrernum.ID + " se guardaron exitosamente \n");

                    fw.close();

                } catch (IOException ex) {
                    Logger.getLogger(Personas.class.getName()).log(Level.SEVERE, null, ex);
                }

            } else {
                recorrernum.saldo = recorrernum.saldo - recorrernum.apuesta;
                //Cada vez que termine el ciclo al perdedor le resta de su saldo

            }
            contador++;

            recorrernum = recorrernum.siguiente;
        }
        partida++;

    }
    
    public void leerganadores() throws IOException {

        int contadorg = 1; 
        System.out.println("Hay "+partida+" partidas");
        System.out.print("Por favor ingrese el número de partida a la que desea ingresar: ");
        contadorg = entrada.nextInt();

        try {
            FileReader fr = new FileReader("C:\\Users\\OROZCO\\Downloads\\Telegram Desktop\\GANADORES"+contadorg+".txt");
            BufferedReader br = new BufferedReader(fr);
            String cadena;

            while ((cadena = br.readLine()) != null) {
                System.out.println("" + cadena);
            }

        } catch (Exception ex) {

        }

        System.out.println("____________________________________");

    }

    public void Modificardatos() {
        int identificacion; //Variable local para hallar que vamos a modificar
        int opc2; // Variable local para las opciones dentro del pequeño menú
        Nodo recorrerN = iniciocola;
        System.out.println("");
        System.out.print("Por favor ingrese el ID del jugador que va a modificar: ");
        identificacion = entrada.nextInt();

        while (recorrerN != null) {

            if (recorrerN.ID == identificacion) {
                do {
                    System.out.println("");

                    System.out.println("Vas a cambiar los valores de: " + recorrerN.nombre);
                    System.out.println("\0331- Cambiar nombre");
                    System.out.println("\0332- Cambiar número");
                    System.out.println("\0333- Cambiar apuesta");
                    System.out.println("\0334- REGRESAR");
                    System.out.println("____________________________________");
                    System.out.print("\033[32mOPCION: ");
                    opc2 = entrada.nextInt();

                    switch (opc2) {

                        case 1:
                            System.out.println("");
                            System.out.println("ingrese el valor del nuevo nombre");
                            recorrerN.nombre = entrada.next();
                            System.out.println("LISTO");
                            System.out.println("____________________________________");
                            break;

                        case 2:
                            System.out.println("");
                            System.out.println("Ingrese el nuevo número");
                            recorrerN.num = entrada.nextInt();
                            System.out.println("LISTO");
                            System.out.println("____________________________________");
                            break;

                        case 3:
                            System.out.println("");
                            System.out.println("Ingrese la nueva apuesta");
                            recorrerN.apuesta = entrada.nextInt();
                            System.out.println("LISTO");
                            System.out.println("____________________________________");
                            break;

                        case 4:
                            opc2 = 10;
                            System.out.println("____________________________________");
                            break;

                        default:
                            System.out.println("OPCIÓN INCORRECTA");

                    }

                } while (opc2 < 5);

                System.out.println("____________________________________");

            }
            recorrerN = recorrerN.siguiente;

        }

    }

}
