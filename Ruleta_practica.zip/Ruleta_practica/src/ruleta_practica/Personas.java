package ruleta_practica;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Personas {

    public String nombre;
    public int apuesta;
    public int num;
    private int a;
    public int ID;
    int contador = 1;

    Scanner entrada = new Scanner(System.in);

    Personas(int a) {
        this.a = a;
    }

    public void Instrucciones() {

        int opc = 1;
        System.out.println("INGRESAR");
        System.out.println("________________________________________________");
        System.out.println("  Para ingresar de manera correcta un jugador Es");
        System.out.println("necesario que sólo se coloque el primer nombre");
        System.out.println("________________________________________________");
        System.out.println("");

        System.out.println("LECTURA DE ARCHIVOS");
        System.out.println("________________________________________________");
        System.out.println("  Para leer los archivos es necesario colocar el");
        System.out.println("número de identificación del jugador se 1,2,3");
        System.out.println("esto únicamente cuando ya ha sido registrado");
        System.out.println("________________________________________________");
        System.out.println("");
        System.out.println("");

        System.out.println("Opción JUGADOR");
        System.out.println("________________________________________________");
        System.out.println("  En ella se encuentran todas las opciones para");
        System.out.println("registrar correctamente al usuario");
        System.out.println("");
        System.out.println("________________________________________________");
        System.out.println("");
        
        System.out.println("IMPORTANTE");
        System.out.println("________________________________________________");
        System.out.println(" Para que funcione correctamente los archivos es");
        System.out.println("necesario cambiar la ruta donde se va a guardar en");
        System.out.println("su computador, puede encontrarlo facilmente en la");
        System.out.println("la clase Cola");
        System.out.println("");
        System.out.println("________________________________________________");
        System.out.println("");
        System.out.println("Presione 0 para continuar");
        opc = entrada.nextInt();
        System.out.println("________________________________________________");
        System.out.println("");
    }

    public void Ruleta() {
        int Ruleta = 0;
        String color;

        Ruleta = (int) (Math.random() * 36);

        if (Ruleta % 2 != 0) {
            color = "Negro";            
        } else {
            color = "Rojo";
        }
        
        System.out.println("El número Ganador es el número "+Ruleta+" de Color "+color);

    }
    
    

}
